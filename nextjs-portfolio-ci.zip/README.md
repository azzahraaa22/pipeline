# 🚀 Next.js Portfolio with CI/CD

This project demonstrates a CI/CD pipeline using GitHub Actions to:

- Run SAST scan with Semgrep
- Deploy to Vercel
- Run DAST scan with OWASP ZAP

## 🔧 GitHub Secrets

Set the following secrets in your GitHub repo:

- `SEMGREP_APP_TOKEN`
- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
